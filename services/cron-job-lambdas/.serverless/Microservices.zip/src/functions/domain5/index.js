
export const handler = async (event) => {
  console.log('Holiss: domain5');
  return 'domain5';
};